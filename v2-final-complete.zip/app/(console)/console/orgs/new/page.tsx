import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import Link from 'next/link'
import { NewOrgWizard } from './wizard'

/**
 * v2.0 재작성 — 신규 Org 생성
 *
 * v2 신규 4가지 설정 (모두 orgs 컬럼):
 *   - default_discount_rate         : 기본 할인율 (예: 0.10 = 10%)
 *   - billing_day_of_month          : 결제일 (1~28)
 *   - wallet_default_validity_months: 잔액 유효기간 개월 (기본 12)
 *   - self_approval_headroom_krw    : Org headroom 한도
 *
 * 기존 wizard.tsx 는 v1 시절 흐름이라 v2 추가 필드는 본 page에서 별도 form 으로 입력.
 * Phase 2에 wizard 자체 v2 통합 권장.
 */
export default async function NewOrgPage({
  searchParams,
}: {
  searchParams: { error?: string; ok?: string }
}) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/console/login')

  const { data: adminUser } = await supabase
    .from('admin_users')
    .select('id, role')
    .eq('email', user.email ?? '')
    .eq('is_active', true)
    .maybeSingle()
  if (!adminUser) redirect('/console/login')

  // v2 정책: Org 생성은 슈퍼어드민(role='super')만
  if (adminUser.role !== 'super') {
    redirect('/console/home?error=' + encodeURIComponent('Org 생성 권한 없음 (super only)'))
  }

  return (
    <div className="max-w-3xl mx-auto py-8 px-4 space-y-6">
      <div>
        <Link href="/console/orgs" className="text-xs text-gray-500 hover:underline">
          ← Org 목록
        </Link>
        <h1 className="text-2xl font-semibold mt-2">신규 Org 생성</h1>
        <div className="text-xs text-gray-500 mt-1">
          기본 정보는 마법사로, v2.0 빌링 정책은 아래 폼으로 입력합니다.
        </div>
      </div>

      {searchParams.error && (
        <div className="border-l-[3px] border-l-red-500 pl-3 py-2 text-sm text-red-700 bg-red-50">
          {decodeURIComponent(searchParams.error)}
        </div>
      )}
      {searchParams.ok && (
        <div className="border-l-[3px] border-l-green-500 pl-3 py-2 text-sm text-green-700 bg-green-50">
          Org 생성 완료
        </div>
      )}

      <section className="border border-gray-200 p-5">
        <h2 className="text-base font-medium mb-3">1. Org 기본 정보 (마법사)</h2>
        <NewOrgWizard />
      </section>

      <section className="border border-gray-200 p-5 space-y-4 bg-gray-50">
        <div>
          <h2 className="text-base font-medium">2. v2.0 빌링 정책</h2>
          <div className="text-xs text-gray-500 mt-1">
            마법사 완료 후 별도 입력. /console/orgs/[id]/policy 에서 사후 변경 가능.
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <Field
            label="기본 할인율"
            description="가입 시 6개월 한정 할인. 0.10 = 10% (세계 발행액 = gross × 0.9)"
            input={
              <input
                type="number"
                step="0.01"
                min="0"
                max="1"
                defaultValue="0.10"
                placeholder="0.10"
                className="w-full border border-gray-300 px-3 py-2 font-mono text-sm"
              />
            }
          />

          <Field
            label="결제일 (1~28)"
            description="매월 헤드룸 리셋·세금계산서 발행 기준일"
            input={
              <input
                type="number"
                min="1"
                max="28"
                defaultValue="1"
                placeholder="1"
                className="w-full border border-gray-300 px-3 py-2 font-mono text-sm"
              />
            }
          />

          <Field
            label="잔액 유효기간 (개월)"
            description="충전 잔액 미사용 시 자동 만료. 기본 12개월."
            input={
              <input
                type="number"
                min="1"
                max="60"
                defaultValue="12"
                placeholder="12"
                className="w-full border border-gray-300 px-3 py-2 font-mono text-sm"
              />
            }
          />

          <Field
            label="Org headroom 한도 (KRW)"
            description="자율승인 가능 월 한도. 팀별 분배의 상한."
            input={
              <input
                type="number"
                min="0"
                step="100000"
                defaultValue="5000000"
                placeholder="5000000"
                className="w-full border border-gray-300 px-3 py-2 font-mono text-sm"
              />
            }
          />
        </div>

        <div className="text-xs text-gray-500 border-l-[3px] border-l-yellow-500 pl-3 py-2 bg-yellow-50">
          현재 wizard.tsx 와 actions.ts 는 v1 흐름 — Phase 2 에 v2 필드 통합 예정.
          본 페이지는 의도 노출용. 실 저장은 Org 생성 후 /console/orgs/[id]/policy 에서 진행.
        </div>
      </section>
    </div>
  )
}

function Field({ label, description, input }: { label: string; description: string; input: React.ReactNode }) {
  return (
    <div>
      <label className="block text-sm font-medium">{label}</label>
      <div className="text-xs text-gray-500 mt-0.5 mb-2">{description}</div>
      {input}
    </div>
  )
}
