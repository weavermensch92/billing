# 01_Product — 4제품 정체성 + 경계 + 외부 노출

> 그릿지 AIMSP = **AI Observer** + **LucaPus** + **Wiring AI** + **Billing MSP**. 네 제품이 어떻게 서로 연결되고 분리되는지.
> **Billing MSP** 는 Mode D (Billing Proxy) 로 기존 Mode A/B/C (AI 실행 레일) 와 직교하는 **결제 레일**. 한 고객이 Mode A + Mode D 병행 보유 가능.
> 외부(파트너/데모/제안서)에서 각 제품을 어떻게 부를지까지 포함.
> 규칙 ID: G-001~G-019.

---

## 1. 4제품 정체성 (G-001)

### 1.1 제품 정의

| 제품 | 한 줄 정의 | 배포 방식 | 주 고객 |
|---|---|---|---|
| **AI Observer** (AI 옵저버) | 기업의 AI 사용을 수집·분석하고 조직 AI 역량을 키우는 모니터링 플랫폼 | SaaS (API 프록시 + 브라우저 익스텐션 + 크롤러) | 10~200인 IT 기업, CTO/대표 |
| **LucaPus** (AI Dev Platform 엔진) | CLI에 설치되어 스펙 분석 → 코드 → 검증 → 배포를 수행하는 AI 개발 엔진 | 고객 환경에 CLI로 설치 | 중견기업 이상, 개발팀 |
| **Wiring AI** (AI 개발팀 가시화) | 개발자가 AI를 적합화하며 개발하고, 그 과정이 조직 전체에 가시화되는 B2B 플랫폼 | SaaS (웹 UI) + IDE 플러그인 | 엔터프라이즈 |
| **Billing MSP** (AI Account MSP) | 기업의 모든 AI 서비스 계정을 그릿지가 대신 구매·관리·청구하는 **리셀러 MSP** (Mode D) | SaaS (고객 포털 + 운영 콘솔) | 스타트업 ~ 중견기업, CFO / 총무 / 대표 |

### 1.2 각 제품의 핵심 가치

**AI Observer:**
- 문제 진단 도구. "누가 AI를 얼마나, 어떻게 쓰는지" 가시화
- AI 성숙도 평가 (Level 1~5) + 코칭
- 비용 이상 / 보안 리스크 조기 탐지

**LucaPus:**
- 4-Plane 아키텍처 (Policy / Spec / Dev / Ops)
- 3 Orchestrators + 추론 격리
- SSOT Verifier / 4-Tier Gate 정합성 보장
- 적합화 엔진 핵심: spec-common D-001~D-105

**Wiring AI:**
- 적합화 = 개발자의 결정이 쌓이는 시스템
- HITL 4종 노드 (`06_hitl.md` 참조)
- 위계별 역할 분리 (L2 비즈니스 / L3 기술)
- 온톨로지 기반 네트워크 추천 (340개+ 프로젝트)

**Billing MSP:**
- **리셀러 구조** (PG 아님) — 그릿지 대지급 → 월말 재청구 (PB-001)
- 3단 티어 (월간 / 주간 중간 + 월 세계서 / 선불) (PB-003)
- 최초 6개월 원가 −10% 크레딧백 (PB-004)
- Anthropic 파트너십 10% 패스스루 (PB-007)
- 전담 AM (Service-First), 벤더 약관 실사 화이트리스트 (PB-006)

### 1.3 관계 요약

```
    고객 진입 (경영자)
         ↓
       AI Observer           "AI 쓰고 있는데 현황이 안 보여요"
         ↓ (진단 → 처방 업셀)
       Wiring AI       "개발자가 AI를 적합화하며 개발"
         ↓ (UI) ↕ (엔진)
       LucaPus         "실제 코드/검증/배포 수행"
```

- **Wiring = 판매 본체**
- **AI Observer = 진입 도구 + 업셀 리드젠**
- **LucaPus = Wiring의 내부 엔진 (외부 비노출)**

---

## 2. 제품 간 경계와 연동 (G-002)

### 2.1 AI Observer ↔ Wiring

Wiring 고객에게 AI Observer 기능은 **별도 구독이 아니라 내장 탭**.

| AI Observer 기능 | Wiring 내 위치 | 식별자 |
|---|---|---|
| 사용 현황 가시화 | 보고서 탭 | `F-008` |
| 실시간 로그 | 로그 탭 | `F-006` |
| 비용 추적 | 설정 > 비용 관리 | `F-010-06` |
| 이슈 감지 (비용 폭증/재질문) | 적합화 큐의 알림 카드 | `F-002` |
| AI 성숙도 평가 | 보고서 > ROI 계산기 | `F-008-04` |
| 개인 코칭 | Stage 0~1에서 적합화 추천으로 대체 | `F-002` |

연동 구현 상세: `integrations/aiops-wiring.md` (I-001).

### 2.2 Wiring ↔ LucaPus

웹 UI(Wiring)와 CLI 엔진(LucaPus)은 **적합화 데이터를 실시간 동기화**.

| LucaPus 원본 | Wiring 화면 대응 | 상속 |
|---|---|---|
| `spec-common.yaml` (D-001~D-105) | 설정 > 개발 규칙 관리 | 조직 → 팀 → 프로젝트 |
| `rules.md` (코딩 하드 게이트) | 설정 > 아키텍처 분석 | 조직 → 팀 → 프로젝트 |
| `architecture.md` | 설정 > 아키텍처 분석 | 프로젝트 단위 |
| `CLAUDE.md` (AI 컨텍스트) | 자동 생성 (비노출) | 프로젝트 단위 |
| Feature Kit | 기획서 분석 R1~R7 | 프로젝트 단위 |
| Core Baseset | 코드 예시 | 프로젝트 단위 |

**원칙:** 한쪽에서 수정하면 실시간 반영 (양방향 동기화). 연동 상세: `integrations/wiring-lucapus.md` (I-002).

### 2.3 LucaPus → AI Observer

LucaPus 엔진이 실행하는 모든 에이전트 호출은 **AI Observer 로그로 자동 수집**.

- 어떤 에이전트가 어떤 모델을 호출했는지
- 토큰 사용량 / 비용 / Latency
- 모드별 분기 (A=토큰, B=자원, C=USD)

연동 상세: `integrations/lucapus-aiops.md` (I-003).

### 2.4 경계 원칙

- **AI Observer ↔ LucaPus 직접 연동 없음.** 항상 Wiring을 경유
- **제품 간 결합 코드는 `integrations/` 에만.** 제품 내부 파일에 타 제품 로직 쓰기 금지
- Mode B (온프레)에서 AI Observer 크로스 고객사 통계는 **자동 제외** (G-084)

---

## 3. AI Observer 판매 분기 (G-003)

### 3.1 두 가지 경로

| 경로 | 대상 | AI Observer 위치 | BM |
|---|---|---|---|
| **A. 단독 판매** | Wiring 미도입 고객 (AI 현황만 보고 싶은 기업) | 독립 SaaS | Starter ₩29만 / Growth ₩99만 |
| **B. Wiring 내장** | Wiring 도입 고객 | Wiring 내 탭 | Wiring 라이선스에 포함 (추가 비용 X) |

### 3.2 단독 → 내장 전환 시

AI Observer 단독 구독 고객이 Wiring으로 업그레이드하면:

1. 기존 AI Observer 데이터 유지 (로그/사용자/이슈 이력 그대로)
2. AI Observer 구독료가 Wiring 라이선스에 **흡수** (고객 입장에서 추가 비용 없음)
3. Wiring 위계가 새로 생성 (AI Observer `super_admin` → Wiring OA 기본 매핑)
4. UI 전환: 독립 AI Observer 대시보드 → Wiring 내 탭으로 이동

### 3.3 가격 전환 시나리오

```
무료 체험 (2주)   ₩0
        ↓
AI Observer 단독      ₩29~99만/월
        ↓ 업셀
Wiring Stage 0   ₩500~1,500만 (1회 구축)
        ↓
Wiring 라이선스  ₩29~99만/월 (AI Observer 포함)
        ↓
엔터프라이즈     협의 (+ 기술 지원 ₩300~600만/년)
```

### 3.4 AI Observer 단독 판매 시 주의

- **Wiring 기능 노출 금지** (적합화 탭 / 파이프라인 / HITL 등)
- 제품명 전면 노출: `AI Observer` (영문) 또는 `AI 옵저버` (한글)
- 연동 상세: `integrations/aiops-standalone.md` (I-004)

---

## 4. 외부 노출 용어 분기 (G-004) — 핵심

### 4.1 외부 노출 수위 매트릭스

| 대상 | AI Observer 노출 | Wiring 노출 | LucaPus 노출 | 하네스/IR/DevPlane/Paperclip 노출 |
|---|---|---|---|---|
| **고객 (도입 검토 중)** | ✅ 전면 | ✅ 전면 | ❌ 금지 | ❌ 금지 |
| **파트너 (Anthropic/Google 등)** | ✅ 전면 | △ 필요 시만 | ❌ 금지 | ❌ 금지 |
| **세일즈 데모** | ✅ 전면 | ✅ 전면 | ❌ 금지 | ❌ 금지 |
| **외부 제안서 / 자료** | ✅ | ✅ | ❌ | ❌ |
| **내부 (팀/룰북)** | ✅ | ✅ | ✅ | ✅ |

### 4.2 외부 노출 금지 용어 (절대 금지)

다음 용어는 **파트너/데모/제안서 어디에도 등장하면 안 된다:**

`LucaPus`, `하네스`, `IR`, `DevPlane`, `voyage`, `Paperclip`, `SSOT Verifier`, `4-Tier Gate`, `SSOT Master`, `Scrum Master (에이전트명)`, `Tech Leader (에이전트명)`, `spec-common`, `R1~R7`, `E0~E5`, `Enhancer`, `Judge`, `Sentinel`, `BTS B-layer`

**Billing MSP 전용 금지어** (법적 리스크, PB-001-03):

`결제 대행`, `결제대행`, `payment processing`, `PG`, `전자지급결제대행`, `정산서`, `결제대행수수료`

### 4.3 외부 대안 표현 (허용)

| 내부 용어 | 외부 대안 |
|---|---|
| LucaPus | "AI 개발 엔진" / "그릿지 플랫폼" |
| 하네스 | "AI 총괄" (최소) 또는 언급 안 함 |
| 하네스 AI | "그릿지 AI 오케스트레이터" (최소) |
| IR / DevPlane | "내부 아키텍처" (불명확하게) |
| Paperclip | "오케스트레이션 엔진" |
| spec-common | "개발 규칙" / "적합화 규칙" |
| 3 Orchestrators | "AI 에이전트 팀" |
| R1~R7 | "기획서 분석 7단계" |
| 적합화 | "적합화" (그대로 사용 가능 — 고유 개념) |
| 결제 대행 ❌ | **"AI 서비스 통합 관리"** / "AI 계정 MSP" / "재판매" |
| 결제대행수수료 ❌ | **"상품·용역 매출 세금계산서"** |
| PG 경로 ❌ | **"대지급·재청구"** / "리셀러 구조" |

### 4.4 파트너별 특수 규칙

**Anthropic 대상:**
- "Claude Code 기반으로 고객사에 AI 개발 서비스를 제공합니다"
- "HITL 기반으로 Claude 코드 품질을 관리합니다"
- AI Observer는 "Claude 사용 현황 모니터링 + 최적화 서비스"로 포지셔닝
- GPT-5.4(Codex) 교차 검증 사실 **비공개**

**Google/Microsoft 대상:**
- Gemini/Azure OpenAI 라우팅 가능하다는 사실 노출 OK
- 멀티 LLM이 경쟁이 아니라 "고객 선택권"으로 프레임

**Upstage 대상:**
- Solar 라우팅 가능 + 한국어 특화 장점 노출 OK
- 내부 라우팅 로직의 우선순위(Claude > GPT > Solar > Gemini)는 **비공개**

### 4.5 레퍼런스 스토리 표현 규칙

기존 Gridge 엔터프라이즈 고객(코레일/Hybe/현대 계열/LG 계열/삼성 계열)을 AI 제품 레퍼런스로 언급할 때:

| 표현 | 허용 여부 | 이유 |
|---|---|---|
| "Gridge가 코레일의 AI 개발 체계 구축을 도왔다" | ✅ | 과장 없음 + 포지셔닝("돕는다") 부합 |
| "Gridge가 Wiring이라는 플랫폼을 코레일에 납품했다" | △ | 제품 노출 깊이 관리 필요 |
| "코레일이 Wiring 도입 후 개발 생산성 300% 증가" | ❌ | 증명 불가능한 수치 + 과한 노출 |
| "Gridge의 LucaPus 엔진이 하네스를 통해..." | ❌ | 내부 아키텍처 과노출 |

**원칙:** 기존 외주/인력 매칭 레퍼런스를 "AI 개발 체계 구축 지원"으로 자연스럽게 연결. 실적 유무를 호도하지 않음.

### 4.6 자동 감지 규칙

`93_workflow § G-209` PR 본문 자동 생성 시 **외부 노출 대상 문서에 금지어가 포함되면 Conflict 발동.**

감지 대상:
- `marketing/` 하위 문서
- `proposals/` 하위 문서
- `demo/` 하위 문서
- 파일명 `*-partner*`, `*-sales*`, `*-demo*` 패턴

---

## 5. 제품 전략 3원칙 (G-005)

PRD 교정 원칙에서 승격. 모든 UI/문서/코드에서 지켜야 함.

### 5.1 원칙 1 — 적합화 = 개발자의 일

- 기술 결정·코드 패턴 승격·아키텍처 판단 → 개발자/기술 리드
- PM에게 올라오는 건 비즈니스 결정만 (전체의 10% 이하)
- PM이 기술 결정 큐를 처리하는 UI/코드/문서 표현 **금지**

### 5.2 원칙 2 — 판매 대상 = CTO/기술 리드 → PM 확장

- 1차 메시지: "개발자의 역할이 바뀝니다" (CTO/기술 리드 대상)
- 2차 메시지: "개발 과정이 처음으로 보입니다" (PM/경영진 확장)
- 데모 트랙 순서: A(기술 리드) → B(PM) 순서 고정

### 5.3 원칙 3 — "너희가 하는 걸 우리가 돕는다"

- ❌ "Gridge가 만들어서 납품한다"
- ✅ "귀사 개발팀이 AI 개발 체계를 구축하는 걸 Gridge가 돕는다"
- 구축 후 귀사가 독립적으로 운영
- 적합화 데이터 = 고객의 것 (YAML/JSON/ZIP 내보내기 가능)

---

## 6. BM 요약 (G-006)

### 6.1 라이선스 플랜

| 플랜 | 대상 | 월 가격 | 포함 |
|---|---|---|---|
| **Starter** | ~20인 | ₩29만 | AI Observer 단독 + 기본 코칭 |
| **Growth** | ~100인 | ₩99만 | AI Observer 전체 + 컴플라이언스 + Wiring Stage 0 |
| **Enterprise** | 100인+ | 협의 | Wiring 전체 + 전담 CS + 커스텀 |

### 6.2 모드별 AI 비용

| 모드 | AI 비용 위치 | 고객 부담 |
|---|---|---|
| A 매니지드 | 그릿지 토큰 | 라이선스에 포함 또는 추가 토큰 구매 |
| B 온프레미스 | 고객 인프라 | 고객 자체 부담 (전력/GPU) |
| C 고객 API | 고객 API 키 | 고객이 Anthropic/OpenAI 등에 직접 지불 |

### 6.3 데이터 소유

적합화 데이터 = 고객의 것. Gridge 서비스 종료 시 ZIP 내보내기 자동 생성 + 30일 유예.

---

## 7. 제품 간 결합도 체크리스트

코드 리뷰 / PR 시 자동 점검 항목 (`93_workflow § G-212` 연계):

- [ ] AI Observer 제품 파일이 Wiring 내부 로직을 직접 import 하고 있지 않은가?
- [ ] Wiring 내부 코드가 LucaPus 내부 구조를 전제로 하고 있지 않은가? (반드시 `integrations/` 경유)
- [ ] AI Observer 단독 판매 시 Wiring 기능이 노출되지 않는가? (`I-004`)
- [ ] Mode B 고객 데이터가 AI Observer 크로스 통계에 포함되지 않는가? (`G-084`)
- [ ] 외부 문서에 G-004 금지 용어가 포함되지 않았는가?
- [ ] 제품 전략 3원칙(G-005) 중 원칙 1(적합화=개발자) 위반 없는가?

위반 감지 → Conflict 자동 발동 (`91 § 1`).

---

## 8. 참조

- AI Observer 제품 상세: `products/aiops/CLAUDE.md`
- LucaPus 제품 상세: `products/lucapus/CLAUDE.md`
- Wiring 제품 상세: `products/wiring/CLAUDE.md`
- 제품 간 연동: `integrations/*.md`
- HITL 설계 원칙: `06_hitl.md`
- 위계 / 판매 대상별 기능: `03_hierarchy.md`
- LucaPus 정합성 7원칙: `CLAUDE.md § 6`
- 파트너 분기 전략: 프로젝트 문서 `01_전략_전환_핵심요약_v2.md`, `03_Anthropic_파트너십_*`
